#ifndef SHELLER_H
#define SHELLER_H
#include <ColoredVertexMatrix.h>

class Sheller{

public:

    Sheller(ColorVertexmatrix matrix_in){



    }
private:
    ColoredVertexMatrix matrix;


};






#endif // SHELLER_H
