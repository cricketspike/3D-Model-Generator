#ifndef VOTINGMATRIX_H
#define VOTINGMATRIX_H

#include "stdafx.h"
#include "Matrix_2D.h"
#include "MatrixNode.h"
#include <cassert>
#include<vector>
#include<string.h>
#include<stdio.h>
#include<iostream>
class VotingMatrix {
public:
	VotingMatrix(int width, int height, int depth,Matrix_2D image);
	void initMatrix();
	MatrixNode getValue(int x, int y, int z);
	void setValue(int x, int y, int z, MatrixNode value);
	int getWidth();
	int getHeight();
	int getDepth();
protected:


private:
	std::vector<std::vector<std::vector<MatrixNode*>>> matrix;
	int m_width;
	int m_height;
	int m_depth;
	Matrix_2D m_image;
	MatrixNode *createElement(int wid, int hei, int dep);

};

#endif // !VOTINGMATRIX_H