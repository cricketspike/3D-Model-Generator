#include "stdafx.h"
#include "Matrix_2D.h"
#include "VotingMatrix.h"
#include <vector>

VotingMatrix::VotingMatrix(int width, int height, int depth, Matrix_2D image) {
	m_width = width;
	m_height = height;
	m_depth = depth;
	m_image = image;
	initMatrix();
	for (int i = 0; i < width; i++) {
		for (int j = 0; j < height; j++) {
			for (int k = 0; k < depth; k++) {
				matrix[i][j][k]=createElement(i,j,k);
			}
		}
	}
}

MatrixNode VotingMatrix::getValue(int x, int y, int z) {
	if (x < 0 || x >= m_width) {
		std::cerr << "error: x is out of bounds, x =" << x << "total width=" << m_width << std::endl;
		exit(1);
	}
	if (y < 0 || y >= m_height) {
		std::cerr << "error: y is out of bounds, y =" << y << "total height=" << m_height << std::endl;
		exit(1);
	}
	if (z < 0 || z >= m_depth) {
		std::cerr << "error: z is out of bounds, z =" << z << "total depth=" << m_depth << std::endl;
		exit(1);

	}
	return *matrix[x][y][z];

}

void VotingMatrix::setValue(int x, int y, int z, MatrixNode value) {
	if (x < 0 || x >= m_width) {
		std::cerr << "error: x is out of bounds, x =" << x << "total width=" << m_width << std::endl;
		return;
	}
	if (y < 0 || y >= m_height) {
		std::cerr << "error: y is out of bounds, y =" << y << "total height=" << m_height << std::endl;
		return;
	}
	if (z < 0 || z >= m_depth) {
		std::cerr << "error: z is out of bounds, z =" << z << "total depth=" << m_depth << std::endl;
		return;
	}
	matrix[x][y][z] = &value;
}

void VotingMatrix::initMatrix() {//creates a 3d matrix[width][height][depth] wtih all elements initialized to 0
	matrix =
		std::vector<std::vector<std::vector<MatrixNode*>>>(
			m_width,
			std::vector<std::vector<MatrixNode*>>(
				m_height,
				std::vector<MatrixNode*>(

					m_depth, nullptr

					)
				)
			);
}

MatrixNode *VotingMatrix::createElement(int i_wid, int j_hei, int k_dep) {

	int image_width = m_image.getImageWidth();
	int image_height = m_image.getImageHeight();
	char u = m_image.getU();
	char v = m_image.getV();




	if (u == 'x') {
		if (image_width != m_width) {
			std::cerr << "error: image has width of " << image_width << "trying to project on a cube's width of" << m_width << std::endl;
			exit(1);
		}
		if (m_image.invertU()) {
			i_wid = image_width - 1 - i_wid;
		}
		if (v == 'y') {//front/back
			if (m_image.getImageHeight() != m_height) {
				std::cerr << "error: image has height of " << image_height << "trying to project on a cube's height of" << m_height << std::endl;
				exit(1);
			}


			if (m_image.invertV()) {
				j_hei = image_height - 1 - j_hei;
			}
			if (m_image.invertDepth()) {
				k_dep = m_depth - 1 - k_dep;
			}
			uint8_t *colors = m_image.getValue(i_wid, j_hei);
			return new MatrixNode(colors[0], colors[1], colors[2], k_dep);
		}
		else if (v == 'z') {//up/down (same horizontal axis)
			if (m_image.getImageHeight() != m_depth) {
				std::cerr << "error: image has height of " << image_height << "trying to project on a cube's depth of" << m_depth << std::endl;
				exit(1);
			}
			if (m_image.invertV()) {
				j_hei = m_depth - 1 - j_hei;
			}
			if (m_image.invertDepth()) {
				k_dep = image_height - 1 - k_dep;
			}
			uint8_t *colors = m_image.getValue(i_wid, j_hei);
			return new MatrixNode(colors[0], colors[1], colors[2], m_depth);
		}
	}
	else if (u == 'z'&&v == 'y') {//left/right(same vertical axis)
		if (image_width != m_depth) {
			std::cerr << "error: image has width of " << image_width << "trying to project on a cube's depth of" << m_depth << std::endl;
			exit(1);
		}
		if (m_image.getImageHeight() != m_height) {
			std::cerr << "error: image has height of " << image_height << "trying to project on a cube's height of" << m_height << std::endl;
			exit(1);
		}
		if (m_image.invertU()) {
			i_wid = m_depth - 1 - i_wid;
		}
		if (m_image.invertV()) {
			j_hei = image_height - 1 - j_hei;
		}
		if (m_image.invertDepth()) {
			k_dep = image_width - 1 - k_dep;

		}
		uint8_t *colors = m_image.getValue(i_wid, j_hei);
		return new MatrixNode(colors[0], colors[1], colors[2], m_depth);
	}
	else {
		std::cerr << "error: image does not have the right angles UV= " <<u<<", "<<v <<std::endl;
		return nullptr;
	}
}

	int VotingMatrix::getWidth() { return m_width; }
	int VotingMatrix::getHeight() { return m_height; }
	int VotingMatrix::getDepth() { return m_depth; }