// Test_ array.cpp : Defines the entry point for the console application.
//

#include "Matrix_2D.h"
#include "stdafx.h"
#include "VotingMatrix.h"
#include "ImageVoter.h"
#include <vector>
#include "ColoredVertexMatrix.h"
int main()
{
	int cube_width=4;
	int cube_height=6;
	int cube_depth=10;


	//front
	Matrix_2D imageF(cube_width, cube_height,'x','y',false,false,false);
	Matrix_2D imageB(cube_width, cube_height, 'x', 'y', true, false, true);
	Matrix_2D imageU(cube_width, cube_depth, 'x', 'z', false, false, false);
	Matrix_2D imageD(cube_width, cube_depth, 'x', 'z', true, false, true);



	VotingMatrix voting_matrixF(cube_width, cube_height, cube_depth,imageF);
	VotingMatrix voting_matrixB(cube_width, cube_height, cube_depth, imageB);
	VotingMatrix voting_matrixU(cube_width, cube_height, cube_depth, imageU);
	VotingMatrix voting_matrixD(cube_width, cube_height, cube_depth, imageD);


	std::vector<VotingMatrix>voing_matrices = { voting_matrixF ,voting_matrixB,voting_matrixU, voting_matrixD };

	ColoredVertexMatrix cvm = ColoredVertexMatrix(cube_width, cube_height, cube_depth, voing_matrices);

    return 0;
}

